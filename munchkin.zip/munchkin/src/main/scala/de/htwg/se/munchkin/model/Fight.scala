package de.htwg.se.munchkin.model

/**
 * @author Vincent76;
 */
class Fight {

}
