package de.htwg.se.munchkin.ui

/**
 * @author Vincent76;
 */
class Commands {

}
